public class tableauEntier{
	public static void main (String[] args){
		
		char n = Integer.parsInt(args[0]);

		if(n < 0){
			System.out.println("Veuillez donner un nombre positif");
		else if{
			System.out.print("[");
			for(int i = 0; i < n ; i++){
				n = (int)(Math.random(8)*(101));
			}
		}
		}
	}
	System.out.println(tableauEntier);
}