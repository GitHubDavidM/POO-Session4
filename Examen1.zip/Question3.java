import java.util.ArrayList;
public class nombreAleatoire{
	public static void main(String[] args){
		
	}
}